const User = require("../models/User");

// Utworzenie klasy kontrolera
class UserController {
    constructor() { }

    // Funkcje statyczne będą dostępne bez tworzenia obiektu i takie same pomiędzy obiektami.
    static registerView = (req, res) => {
        res.render("register");
    }

    static loginView = (req, res) => {
        res.render("login");
    }

    static async registerUser(req, res) {
        // Odczytanie danych z formularza i utworzenie obiektu na podstawie modelu User.js
        let data = req.body
        console.log(`Dane odczytane z formularza: ${JSON.stringify(data)}`)
        // Tworzymy obiekt na podstawie naszego modelu. Jeśli jest prosty framework odszuka po kluczach odpowiednie pola.
        let user = new User(data);
        console.log(`Utworzony obiekt: ${JSON.stringify(user)}`)
        // Zapisanie obiektu w bazie danych.
        try {
            // Funkcja save() jest asynchroniczna - zwraca obietnicę że się wykona. Jeśli chcemy poczekać aż wykona się do końca należy użyć instrukcji await
            await user.save()
        } catch (err) {
            //  Jeśli komunikat błędu zaczyna się od "E11000 duplicate key error"
            if (err.message.startsWith("E11000 duplicate key error")) {
                // wyrenderuj widok register i przekaż komunikat błędu do szablonu
                res.render('register', { error: "Login is taken" });
                return
            } else {
                console.log("Błąd zapisu użytkownika: " + err.message)
            }
        }
        // Przekierowanie użytkownika do 'jakiejś trasy' np. wyświetlającej użytkowników
        res.redirect('/');
    }

    static async usersView(req, res) {
        // Pobranie z bazy Kolekcji Użytkowników
        let data = await User.find().lean()
        // Przekazanie danych do widoku
        console.log("Czy zalogowano:" + req.session.loggedin)
        res.render('usersTable', { data: data, islogged: req.session.loggedin })
    }

    static async login(req, res) {
        let data = req.body
        console.log(data)
        let user = await User.find({ login: data.login }).lean()
        console.log(user)
        // Jeśli znaleziono jednego użytkownika o tym lognie
        if (user.length == 1) {
            // Ustawienie zmiennych sesyjnych
            req.session.loggedin = true;
            req.session.login = user.login;
            res.redirect('/users')
            // W przeciwnym wypadku przenosimy użytkownika do rejestracji
        } else {
            res.redirect('/register')
        }
    }

    static async delete(req, res) {
        console.log(req.session.loggedin)
        if (req.session.loggedin) {
            // Odczyt named parameter
            let id = req.params.id
            // Usunięcie użytkownika o danym id (https://mongoosejs.com/docs/api/model.html)
            await User.deleteOne({ _id: id })
            res.redirect('/users')
        } else {
            // res.redirect('/login')
        }
    }
}

module.exports = UserController;