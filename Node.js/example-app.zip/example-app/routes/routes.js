const express = require('express');
const userController = require('../controllers/userController');
const router = express.Router();

// Import pakietu 'body-parser'. Kiedyś pakiet był częścią frameworku https://www.npmjs.com/package/body-parser
var bodyParser = require('body-parser')
// application/json parser - będziemy używać do przetwarzania JSON
var jsonParser = bodyParser.json()
// application/x-www-form-urlencoded parser - będziemy używać do przetwarzania danych z formularzy HTML
var urlencodedParser = bodyParser.urlencoded({ extended: false })

router.get('/', function (req, res) {
    res.render('index')
});

// Zwrócenie widoku (gdy otrzymamy żądanie HTTP metodą GET)
router.get('/register', userController.registerView);
// Obsługa formularza (gdy otrzymamy żądanie HTTP metodą POST)
router.post('/register', urlencodedParser, userController.registerUser);

router.get('/users', userController.usersView)

router.get('/login', userController.loginView);
router.post('/login',urlencodedParser, userController.login);

router.delete('/delete/:id', userController.delete)

module.exports = router;